var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/789bb_next_478f1c57._.js")
R.c("server/chunks/[root-of-the-server]__59d8b6c5._.js")
R.m("[project]/reactZ2H/vite-project/next-app/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/reactZ2H/vite-project/next-app/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/reactZ2H/vite-project/next-app/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/reactZ2H/vite-project/next-app/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/reactZ2H/vite-project/next-app/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
