globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/789bb_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_226eb043._.js",
    "static/chunks/789bb_next_dist_compiled_react-dom_4ad3997b._.js",
    "static/chunks/789bb_next_dist_compiled_next-devtools_index_98d0b4a7.js",
    "static/chunks/789bb_next_dist_compiled_daba0e1e._.js",
    "static/chunks/789bb_next_dist_client_532769d1._.js",
    "static/chunks/789bb_next_dist_81286ddf._.js",
    "static/chunks/789bb_@swc_helpers_cjs_e07b0ee3._.js",
    "static/chunks/reactZ2H_vite-project_next-app_a0ff3932._.js",
    "static/chunks/turbopack-reactZ2H_vite-project_next-app_a95ffd3b._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];