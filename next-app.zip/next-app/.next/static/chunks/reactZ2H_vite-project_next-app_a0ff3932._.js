(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_226eb043._.js",
  "static/chunks/789bb_next_dist_compiled_react-dom_4ad3997b._.js",
  "static/chunks/789bb_next_dist_compiled_next-devtools_index_98d0b4a7.js",
  "static/chunks/789bb_next_dist_compiled_daba0e1e._.js",
  "static/chunks/789bb_next_dist_client_532769d1._.js",
  "static/chunks/789bb_next_dist_81286ddf._.js",
  "static/chunks/789bb_@swc_helpers_cjs_e07b0ee3._.js"
],
    source: "entry"
});
